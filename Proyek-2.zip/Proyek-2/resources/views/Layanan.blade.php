<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="surat.css">
    <title>Layanan Kotak Saran Desa</title>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <nav>
            </nav>
        </div>
        <main class="content">
              <section class="hero">
                  <!-- <img src="online.png" alt=""> -->
              <div class="hero-content">
                  <h1>Layanan Kotak Saran Desa</h1><br>
                  <p>Silahkan klik tombol di bawah untuk mengisi kotak saran Desa Dermayu</p>
                    <a href="https://api.whatsapp.com/send?phone=6289524175326&text=Silahkan Isi Disini, jangan lupa sertakan nama Anda" class="action-btn">Layanan Surat</a>
              </div>
                </section>
        </div>
    </div>
</body>
</html>
