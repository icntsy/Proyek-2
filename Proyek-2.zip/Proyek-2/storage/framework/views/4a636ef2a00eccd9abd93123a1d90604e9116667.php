<?php $__env->startSection("page_title", "DATA SKU"); ?>

<?php $__env->startSection("page_content"); ?>

<div class="row align-items-center py-4">
  <div class="col-lg-6 col-7">
    <h6 class="h2 text-white d-inline-block mb-0">Default</h6>
    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
        <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
        <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
        <li class="breadcrumb-item active" aria-current="page">Default</li>
      </ol>
    </nav>
  </div>
  <div class="col-lg-6 col-5 text-right">
    <a href="<?php echo e(url('/sku/tambah')); ?>" class="btn btn-sm btn-neutral">Tambah Data</a>
  </div>
</div>

<div class="row">
  <div class="col">
    <div class="card">
      <!-- Card header -->
      <div class="card-header border-0">
        <h3 class="mb-0">
          <?php if(auth()->user()->role == 1): ?>

          Surat Keterangan Usaha

          <?php else: ?>

          Hallo Gaes

          <?php endif; ?>
        </h3>
      </div>
      <!-- Light table -->
      <div class="table-responsive">
        <table class="table align-items-center table-flush">
          <thead class="thead-light">
            <tr>
              <th scope="col" class="sort" data-sort="name">No.</th>
              <th scope="col" class="sort" data-sort="status">Nama</th>
              <th scope="col" class="sort" data-sort="status">Tempat Lahir</th>
              <th scope="col" class="sort" data-sort="budget">Tanggal Lahir</th>
              <th scope="col" class="sort" data-sort="budget">Jenis Kelamin</th>
              <th scope="col" class="sort" data-sort="status">Agama</th>
              <th scope="col" class="sort" data-sort="budget">Pekerjaan</th>
              <th scope="col" class="sort" data-sort="budget">Alamat</th>
              <th scope="col">Aksi</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody class="list">
            <?php $no = 0 ?>

            <?php $__currentLoopData = $data_sku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$no); ?></td>
              <td><?php echo e($sku->nama); ?></td>
              <td><?php echo e($sku->tempat_lahir); ?></td>
              <td><?php echo e($sku->tanggal_lahir); ?></td>
              <td><?php echo e($sku->jenis_kelamin); ?></td>
              <td><?php echo e($sku->agama); ?></td>
              <td><?php echo e($sku->pekerjaan); ?></td>
              <td><?php echo e($sku->alamat); ?></td>
              <td>
                <a href="/editsurat" class="btn btn-warning btn-sm">
                  <i class="fas fa-edit"></i>
                </a>
                <a href="http://127.0.0.1:8080/jasperserver/rest_v2/reports/reports/Sku.pdf?id=<?php echo e($sku->id); ?>" class="btn btn-danger btn-sm" target="_blank">
                  <i class="fas fa-print"></i>
                </a>
                <a onclick="return confirm('Ingin Menghapus Data Ini ?')" href="/sku/<?php echo e($sku->id); ?>/hapus" class="btn btn-warning btn-sm">
                  <i class="fas fa-trash"></i>
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\Proyek-2\Proyek-2\resources\views//sku.blade.php ENDPATH**/ ?>